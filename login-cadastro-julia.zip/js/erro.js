
/* Criando variavel
var btnSingin = document.querySelector("#signin"); /* selecionando o id do botão 
var btnSingup = document.querySelector("#Singup"); /* "recuperando" o "botão" no caso 
var body = document.querySelector("body"); /* "recuperando" o "botão" no caso 



/* Vai "ouvir" os eventos que ocorrem no botçao, o evento é o click e vai disparar uma ação que é add uma classe no body 
btnSingin.addEventListener("click", function() {
    body.className = "sing-in-js" /* recebe a class 
});

btnSingup.addEventListener("click", function() {
    body.className = "sing-up-js";
});*/


/* 
var btnSignin = document.querySelector("#signin");
var btnSignup = document.querySelector("#signup");

var body = document.querySelector("body");


btnSignin.addEventListener("click", function () {
   body.className = "sign-in-js"; 
});

btnSignup.addEventListener("click", function () {
    body.className = "sign-up-js";
})
 */